use strict;
use warnings;

package Tournament;
use base_version::Team;
use base_version::Fighter;

sub new{
}

sub set_teams{
}

sub play_one_round{
}

sub check_winner(){
}

sub input_fighters{
}

sub play_game{
 
}
1;