from advanced_version.AdvancedTournament import AdvancedTournament
from base_version.Tournament import Tournament

if __name__ == "__main__":
    tournament = Tournament()
    tournament.play_game()
