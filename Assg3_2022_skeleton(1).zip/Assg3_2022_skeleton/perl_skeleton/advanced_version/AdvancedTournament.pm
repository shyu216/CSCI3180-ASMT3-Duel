use strict;
use warnings;

package AdvancedTournament;
use base_version::Team;
use advanced_version::AdvancedFighter;
use base_version::Tournament;
use List::Util qw(sum);

our @ISA = qw(Tournament); 


sub new{
}

sub play_one_round{
}

sub update_fighter_properties_and_award_coins{
}

sub input_fighters{
}


1;