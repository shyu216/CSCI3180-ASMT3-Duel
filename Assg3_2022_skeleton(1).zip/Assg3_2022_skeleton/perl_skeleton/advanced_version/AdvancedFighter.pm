use strict;
use warnings;

package AdvancedFighter;

use base_version::Fighter;
use List::Util qw(sum);

our @ISA = qw(Fighter); 

our $coins_to_obtain = 20;
our $delta_attack = -1;
our $delta_defense = -1;
our $delta_speed = -1;


sub new{
}

sub obtain_coins{
}

sub buy_prop_upgrade{
}

sub record_fight{
}


sub update_properties{
}
