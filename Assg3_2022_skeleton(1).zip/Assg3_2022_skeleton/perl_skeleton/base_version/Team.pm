use strict;
use warnings;

package Team;

sub new {};

sub set_fighter_list{
}
sub get_fighter_list{
}

sub set_order{
}
sub get_next_fighter{
}
1;